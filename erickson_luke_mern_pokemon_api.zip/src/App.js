import './App.css';
import PokemonList from './components/PokemonList';

function App() {
  return (
    <div className="App">
      <PokemonList/>
    </div>
  );
}

export default App;
